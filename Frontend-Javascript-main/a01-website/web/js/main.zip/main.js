/*
    If the button is pressed run the function randomWord.
*/
document.getElementById("randomFruit").onclick = function () {
    randomWord();
}

/*  
    The core function which chooses a random word out of the array wordArray.
    Then we use the word and checks how it looks in upper case and lowercase, checks how many letters it has 
    then finally how many vowels and consonants then word has. After that we check if a character that a user
    guessed on is in the word and how many times it is in it.
*/
function randomWord() {
    var guessedCharacter = document.getElementById("characterGuess").value;
    let wordArray = ['Apple', 'Banana', 'Cherry', 'Dates', 'Elderberry', 'Fig', 'Grapefruit',
        'Hackberry', 'Jackfruit', 'Kiwi', 'Lime', 'Mango', 'Nectarine', 'Orange', 'Papaya', 'Quince',
        'Raspberry', 'Strawberry', 'Tangerine', 'Ugni'];
    var randomNumber = getRandomNumber();
    var fruit = wordArray[randomNumber];
    var lowerCase = wordArray[randomNumber].toLowerCase();
    var upperCase = wordArray[randomNumber].toUpperCase();
    var letterCounter = wordArray[randomNumber].length;
    let counters = countVowels(fruit);
    var characterHits = checkAmountOfHits(guessedCharacter, fruit);

    document.getElementById("theFruit").innerHTML = "The random fruit: " + fruit;
    document.getElementById("upperCaseFruit").innerHTML = "The random fruit in lower case: " + lowerCase;
    document.getElementById("lowerCaseFruit").innerHTML = "The random fruit in upper case: " + upperCase;
    document.getElementById("letterCounter").innerHTML = "Amount of letter in " + fruit + ": " + letterCounter;
    document.getElementById("vowelCounter").innerHTML = "Vowels: " + counters[0] + " Consonants: " + counters[1];

    if (checkCharacter(guessedCharacter, fruit)) {
        document.getElementById("fruitContainsCharacter").innerHTML = "Does the fruit " + fruit + " contain character " + guessedCharacter + "? Yes it does!";
    }
    else {
        document.getElementById("fruitContainsCharacter").innerHTML = "Does the fruit " + fruit + " contain character " + guessedCharacter + "? No it does not!";
    }

    document.getElementById("fruitContainsCharacterMultiple").innerHTML = "How many letters of character \"" + guessedCharacter + "\" does the fruit " + fruit + " contain: " + characterHits;

    console.log(wordArray[randomNumber]);
}

//Random number 0-19.
function getRandomNumber() {
    return Math.floor(Math.random() * 20);
}

//Counts how many vowels there are in the word.
function countVowels(fruit) {
    let vowels = ['a', 'e', 'i', 'o', 'u', 'y'];
    var vowelsCounter = 0;
    var consonantCounter = 0;

    for (var vowelCounter = 0; vowelCounter < vowels.length; vowelCounter++) {
        if (fruit.includes(vowels[vowelCounter])) {
            vowelsCounter++;
        }
        else {
            consonantCounter++;
        }
    }

    let counters = [vowelsCounter, consonantCounter];
    return counters;    //Returns the array with the counter for vowels and consonants.
}

//Checks if the character is included in the word.
function checkCharacter(guessedCharacter, fruit) {
    if (fruit.includes(guessedCharacter.toLowerCase()) || fruit.includes(guessedCharacter.toUpperCase())) {
        return true;
    }

    return false;
}

/*
    Checks how many times the character occurs in the word. I do it by splitting the word using the guessed character.
    Then depending on the length of the new array (minus 1) we get the amount of times the character occurs
    in the word.
    Example: We have guessed a and we have Raspberry we split and get [R, spberry] which gives length 2, but
    a only occurs once thats why we reduce it with 1 to get correct amount of hits.
*/
function checkAmountOfHits(guessedCharacter, fruit) {
    var fruitWithoutCharacter = fruit.split(guessedCharacter).length - 1;
    return fruitWithoutCharacter;
}